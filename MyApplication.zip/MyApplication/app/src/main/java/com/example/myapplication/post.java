package com.example.myapplication;

public class post {
    public String userid = "";
    public String id = "";
    public String body = "";
    public String title = "";
    public post(String userid, String id, String title, String body){
        this.userid = userid;
        this.id = id;
        this.title = title;
        this.body = body;
    }
}
