package com.example.myapplication;

public class comment {
    String postId ;
    String id;
    String name;
    String email;
    String body;
    public comment(String postid, String id, String name, String mail, String body){
        this.postId = postid;
        this.id = id;
        this.name = name;
        this.email = mail;
        this.body = body;
    }
}
